<?php
require 'config.php';
if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Ambil daftar kategori
$stmt = $pdo->prepare("SELECT * FROM categories ORDER BY tipe, nama");
$stmt->execute();
$categories = $stmt->fetchAll();

// Proses tambah transaksi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kategori_id = $_POST['kategori_id'];
    $jumlah      = str_replace(',', '', $_POST['jumlah']); // hapus koma
    $keterangan  = trim($_POST['keterangan']);
    $tanggal     = $_POST['tanggal'];
    $tipe        = $_POST['tipe'];

    if ($jumlah > 0) {
        $stmt = $pdo->prepare("INSERT INTO transactions 
            (user_id, kategori_id, jumlah, keterangan, tanggal, tipe) 
            VALUES (?, ?, ?, ?, ?, ?)");
        
        if ($stmt->execute([$user_id, $kategori_id, $jumlah, $keterangan, $tanggal, $tipe])) {
            $success = "Transaksi berhasil ditambahkan!";
        } else {
            $error = "Gagal menambahkan transaksi.";
        }
    } else {
        $error = "Jumlah harus lebih dari 0!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi - FinTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .card { border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-white">
                    <h4><i class="fas fa-plus-circle"></i> Tambah Transaksi Baru</h4>
                </div>
                <div class="card-body p-4">

                    <?php if ($success): ?>
                        <div class="alert alert-success"><?= $success ?></div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Tipe Transaksi</label>
                                <select name="tipe" class="form-select" required onchange="this.form.submit()" style="display:none">
                                    <option value="income" <?= isset($_POST['tipe']) && $_POST['tipe']=='income' ? 'selected' : '' ?>>Pemasukan</option>
                                    <option value="expense" <?= !isset($_POST['tipe']) || $_POST['tipe']=='expense' ? 'selected' : '' ?>>Pengeluaran</option>
                                </select>
                                <div class="btn-group w-100">
                                    <button type="button" class="btn btn-success w-50" onclick="setTipe('income')">Pemasukan</button>
                                    <button type="button" class="btn btn-danger w-50" onclick="setTipe('expense')">Pengeluaran</button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Tanggal</label>
                                <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <select name="kategori_id" class="form-select" required>
                                <option value="">Pilih Kategori</option>
                                <?php foreach($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= $cat['nama'] ?> (<?= $cat['tipe'] == 'income' ? 'Pemasukan' : 'Pengeluaran' ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Jumlah (Rp)</label>
                            <input type="number" name="jumlah" class="form-control" placeholder="0" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Keterangan</label>
                            <textarea name="keterangan" class="form-control" rows="3" placeholder="Contoh: Gaji bulan Mei"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-100">Simpan Transaksi</button>
                    </form>

                    <div class="text-center mt-4">
                        <a href="dashboard.php" class="btn btn-secondary">Kembali ke Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function setTipe(tipe) {
    // Untuk mempermudah, refresh dengan tipe yang dipilih (bisa dikembangkan)
    window.location.reload();
}
</script>
</body>
</html>