from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Sum
from django.utils import timezone
from .models import Transaksi
import csv
import json
from django.http import HttpResponse

# ==========================================
# 1. LOGIKA HALAMAN DASHBOARD PREMIUM
# ==========================================
@login_required(login_url='login')
def dashboard(request):
    # Ambil filter bulan & tahun dari URL (GET). Jika tidak memilih, default ke waktu sekarang.
    bulan_sekarang = timezone.now().month
    tahun_sekarang = timezone.now().year
    
    bulan_dipilih = int(request.GET.get('bulan', bulan_sekarang))
    tahun_dipilih = int(request.GET.get('tahun', tahun_sekarang))

    # Saring transaksi milik user berdasarkan bulan dan tahun yang dipilih
    transaksi_user = Transaksi.objects.filter(
        user=request.user,
        date__month=bulan_dipilih,
        date__year=tahun_dipilih
    ).order_by('-date')
    
    # Hitung total nominal pemasukan & pengeluaran sesuai nama di HTML Anda
    total_masuk = transaksi_user.filter(type='pemasukan').aggregate(Sum('amount'))['amount__sum'] or 0
    total_keluar = transaksi_user.filter(type='pengeluaran').aggregate(Sum('amount'))['amount__sum'] or 0
    saldo = total_masuk - total_keluar

    # --- LOGIKA GRAFIK DONUT (CHART.JS) ---
    kategori_pengeluaran = transaksi_user.filter(type='pengeluaran').values('category').annotate(total=Sum('amount'))
    
    labels_list = []
    values_list = []
    for k in kategori_pengeluaran:
        labels_list.append(k['category'])
        values_list.append(float(k['total']))

    # Convert ke JSON string agar aman dibaca oleh JavaScript di HTML
    chart_labels = json.dumps(labels_list)
    chart_values = json.dumps(values_list)

    # Logika simpan transaksi baru via POST Form
    if request.method == 'POST':
        title = request.POST.get('title')
        amount = request.POST.get('amount')
        type_transaksi = request.POST.get('type')
        category = request.POST.get('category')
        
        if title and amount and type_transaksi:
            Transaksi.objects.create(
                user=request.user,
                title=title,
                amount=amount,
                type=type_transaksi,
                category=category,
                date=timezone.now()
            )
            return redirect(f'/?bulan={bulan_dipilih}&tahun={tahun_dipilih}')

    context = {
        'transaksi': transaksi_user,
        'total_masuk': total_masuk,
        'total_keluar': total_keluar,
        'saldo': saldo,
        'bulan_dipilih': bulan_dipilih,
        'tahun_dipilih': tahun_dipilih,
        'chart_labels': chart_labels,
        'chart_values': chart_values,
    }
    return render(request, 'dashboard.html', context)


# ==========================================
# 2. LOGIKA HALAMAN LOGIN & REGISTER & LOGOUT
# ==========================================
def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username_input = request.POST.get('username')
        password_input = request.POST.get('password')
        user = authenticate(request, username=username_input, password=password_input)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'login.html', {'error': 'Username atau Password salah!'})
    return render(request, 'login.html')

def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username_input = request.POST.get('username')
        email_input = request.POST.get('email')
        password_input = request.POST.get('password')
        password_konfirmasi = request.POST.get('password_konfirmasi')

        if password_input != password_konfirmasi:
            return render(request, 'register.html', {'error': 'Konfirmasi password tidak cocok!'})
        if User.objects.filter(username=username_input).exists():
            return render(request, 'register.html', {'error': 'Username sudah digunakan!'})
        if User.objects.filter(email=email_input).exists():
            return render(request, 'register.html', {'error': 'Email sudah digunakan!'})

        user = User.objects.create_user(username=username_input, email=email_input, password=password_input)
        login(request, user)
        return redirect('dashboard')
    return render(request, 'register.html')

def logout_view(request):
    logout(request)
    return redirect('login')


# ==========================================
# 3. LOGIKA HAPUS TRANSAKSI
# ==========================================
@login_required(login_url='login')
def hapus_transaksi(request, id_transaksi):
    bulan_asal = request.GET.get('bulan', timezone.now().month)
    tahun_asal = request.GET.get('tahun', timezone.now().year)
    try:
        transaksi = Transaksi.objects.get(id=id_transaksi, user=request.user)
        transaksi.delete()
    except Transaksi.DoesNotExist:
        pass
    return redirect(f'/?bulan={bulan_asal}&tahun={tahun_asal}')


# ==========================================
# 4. LOGIKA EXPORT CSV (Filter Sesuai Bulan & Tahun)
# ==========================================
@login_required(login_url='login')
def export_csv(request):
    bulan_dipilih = int(request.GET.get('bulan', timezone.now().month))
    tahun_dipilih = int(request.GET.get('tahun', timezone.now().year))

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="laporan_{bulan_dipilih}_{tahun_dipilih}.csv"'

    writer = csv.writer(response)
    writer.writerow(['Tanggal', 'Judul', 'Kategori', 'Jenis', 'Jumlah'])

    transaksi = Transaksi.objects.filter(
        user=request.user,
        date__month=bulan_dipilih,
        date__year=tahun_dipilih
    ).order_by('-date')

    for t in transaksi:
        writer.writerow([t.date.strftime('%Y-%m-%d %H:%M'), t.title, t.category, t.type, t.amount])

    return response